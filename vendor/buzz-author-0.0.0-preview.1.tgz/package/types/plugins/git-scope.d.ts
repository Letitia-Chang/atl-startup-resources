import type { GitScope } from "./types";
/** Trailing arguments for the Git import calls, empty when the whole repository tip is wanted. */
export declare const gitScope: (commit: string | undefined, path: string | undefined) => [GitScope] | [];
