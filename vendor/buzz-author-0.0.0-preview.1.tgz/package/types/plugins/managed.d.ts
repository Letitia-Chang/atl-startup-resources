import type { ManagedEntry, ManagedPlugins } from "./types";
/** Recommendations that still need the user: not installed, or not at the pinned commit. */
export declare function pendingManaged(managed: ManagedPlugins | undefined): ManagedEntry[];
/** The recommendation an installed plugin came from, for its Managed by label. */
export declare function managedBy(managed: ManagedPlugins | undefined, id: string): {
    source: string;
    entry: ManagedEntry;
} | undefined;
