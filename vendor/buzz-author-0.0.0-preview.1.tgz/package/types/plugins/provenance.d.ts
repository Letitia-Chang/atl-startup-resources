export declare function bundledOwner<T extends object>(owner: T): T;
export declare const isBundledOwner: (owner: object) => boolean;
/** Contribution registries mark an entry a bundled owner registered. */
export declare function bundledContribution(entry: object): void;
export declare const isBundledContribution: (entry: object) => boolean;
