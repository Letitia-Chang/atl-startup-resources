import type { PluginRelease } from "./types";
export declare function samePluginRelease(left: PluginRelease | undefined, right: PluginRelease | undefined): boolean;
