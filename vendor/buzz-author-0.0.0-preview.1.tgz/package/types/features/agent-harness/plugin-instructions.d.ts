import type { TurnInstructions } from "../agents/service";
/** One `<plugin-instructions>` section for each plugin's instructions, or
 * undefined when there are none. A turn's sections are the complete current
 * set, which the base prompt says replaces earlier turns'. Each section names
 * its plugin, so a transcript shows which plugin gave which instructions.
 * That keeps the prompt well formed and attributed; it is not a trust
 * boundary, since the text is the trusted plugin's own. */
export declare function pluginInstructions(entries?: readonly TurnInstructions[]): string | undefined;
/** The `<owner-instructions>` section for one conversation's instructions,
 * named by the plugin that gave them; cleared ones say none apply now. */
export declare function ownerInstructions(entry: TurnInstructions | undefined): string | undefined;
