import type { HourCycle } from "../../shared/clock-preference";
/** A profile's self-declared `tz` when this runtime accepts it as a time
 * zone, else undefined. Kept as written: engines canonicalize aliases such as
 * Asia/Kolkata differently. */
export declare function profileTimeZone(value: unknown): string | undefined;
/** "3:42 PM local time · 8h ahead": the clock in `timeZone` at `now`, and how
 * far it is from the viewer's zone when the two differ at that moment, unless
 * `difference` is false. A
 * different calendar date reads "tomorrow" or "yesterday", or the weekday when
 * the dates are two apart (UTC+14 against UTC-11). Undefined when `timeZone` is
 * not a usable zone. */
export declare function localTimeLabel(timeZone: string | undefined, now: Date, viewerZone: string, options?: {
    locale?: string;
    hourCycle?: HourCycle | undefined;
    difference?: boolean;
}): string | undefined;
