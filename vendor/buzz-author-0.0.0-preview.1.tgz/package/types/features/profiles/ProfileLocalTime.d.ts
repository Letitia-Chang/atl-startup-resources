/** Someone's local time from their profile `tz`, refreshed on each minute;
 * renders nothing when they have not shared a usable zone. */
export declare function ProfileLocalTime({ timeZone, className, }: {
    timeZone: string | undefined;
    className: string;
}): import("react").JSX.Element | null;
