import { Service, type Context } from "@deepseek-ai/cordis";
import type { HostResponse } from "../host/service";
export type SessionSnapshot = Readonly<{
    status: "unconfigured" | "signed-out" | "signing-in" | "restoring" | "signed-in" | "reauthentication-required" | "unavailable";
    authority: Readonly<{
        id: string;
        identityOrigin: string;
        apiBasePath: string;
        /** `at-launch` builds sign in before the app opens; see LaunchSignIn. */
        signIn: "on-demand" | "at-launch";
        /** Display name for sign-in copy, such as "Block". */
        organization: string | null;
        /** The community hosts it covers; match them with `coversCommunity`. */
        communityHosts: readonly string[];
    }> | null;
    revision: string;
    email: string | null;
    failure: string | null;
    /** When the signed-in session ends (RFC 3339). */
    expiresAt: string | null;
    /** The session ends soon; signing in again now keeps the app open. */
    expiring: boolean;
    /** A retired session's record is still stored because removing it
     * failed (`unavailable`); signing out again retries the removal. */
    cleanup: boolean;
    /** Signing in again waits on the browser while this session stays
     * signed in; `cancelSignIn` ends only that wait. */
    renewing?: boolean;
}>;
/** First run's sign-in choices (`FirstRunIdentity`); plugins see `signIn()`. */
export type SignInOptions = Readonly<{
    /** Open the identity provider's sign-up screen: Create account's alone. */
    signup?: boolean;
    /** Ask for credentials over the browser's session: after Use a different account. */
    forceLogin?: boolean;
}>;
export type AuthenticatedRequest = Readonly<{
    path: string;
    method?: "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE";
    headers?: Readonly<Record<string, string>>;
    body?: string;
    /** Native deadline in milliseconds, 1–180000. Defaults to 30000. */
    timeoutMs?: number;
    /** To the server's Apps Platform control plane, as `bl apps` calls it;
     * native allows only the bundled Builderlab plugin. */
    apps?: boolean;
    /** An Apps deploy: a `.tar.gz` file in the home directory, POSTed as a
     * multipart form. */
    upload?: Readonly<{
        field: string;
        path: string;
        name: string;
        contentType: string;
    }>;
}>;
export interface FederatedIdentity {
    /** Granted routes are forwarded natively with the session as a Bearer token. */
    readonly apiAvailable: boolean;
    snapshot(): SessionSnapshot;
    subscribe(listener: () => void): () => void;
    signIn(): Promise<SessionSnapshot>;
    cancelSignIn(): Promise<void>;
    /** Checks a session whose restore failed again, keeping its stored record:
     * native retries the restore; a signed-in session answers as it is. */
    recheck?(): Promise<SessionSnapshot>;
    /** With `revision`, only while that session is current: native leaves a
     * newer one signed in. Answers with native's own snapshot. */
    signOut(options?: {
        revision?: string;
    }): Promise<SessionSnapshot>;
    request(input: AuthenticatedRequest): Promise<HostResponse>;
    /** The session of the sign-in server for a community (`wss://` or
     * `https://` origin). Native chooses the server from the community's host,
     * never from the relay; it is this session for the build's Builderlab. */
    forCommunity?(relay: string): FederatedIdentity;
    /** The session of the sign-in server with this id, for Settings. */
    forServer?(id: string): FederatedIdentity;
    /** Whether a community (`wss://` or `https://` origin) requires NIP-FI,
     * from the `/info` discovery native shares with admission. One that does
     * not is reached with the key alone, whatever any session does. Rejects
     * when discovery fails. */
    communityRequiresSignIn?(relay: string): Promise<boolean>;
    /** The user asked to try a community (`wss://` or `https://` origin) again:
     * its next admission asks the issuer again instead of repeating a refusal
     * native cached for the session (NIP-FA). Automatic retries never call it. */
    askAgain?(relay: string): Promise<void>;
}
declare module "@deepseek-ai/cordis" {
    interface Context {
        federatedIdentity: FederatedIdentity;
    }
}
export declare class FederatedIdentityService extends Service implements FederatedIdentity {
    readonly apiAvailable: boolean;
    private readonly shared;
    constructor(ctx: Context);
    private accept;
    snapshot: () => Readonly<{
        status: "unconfigured" | "signed-out" | "signing-in" | "restoring" | "signed-in" | "reauthentication-required" | "unavailable";
        authority: Readonly<{
            id: string;
            identityOrigin: string;
            apiBasePath: string;
            /** `at-launch` builds sign in before the app opens; see LaunchSignIn. */
            signIn: "on-demand" | "at-launch";
            /** Display name for sign-in copy, such as "Block". */
            organization: string | null;
            /** The community hosts it covers; match them with `coversCommunity`. */
            communityHosts: readonly string[];
        }> | null;
        revision: string;
        email: string | null;
        failure: string | null;
        /** When the signed-in session ends (RFC 3339). */
        expiresAt: string | null;
        /** The session ends soon; signing in again now keeps the app open. */
        expiring: boolean;
        /** A retired session's record is still stored because removing it
         * failed (`unavailable`); signing out again retries the removal. */
        cleanup: boolean;
        /** Signing in again waits on the browser while this session stays
         * signed in; `cancelSignIn` ends only that wait. */
        renewing?: boolean;
    }>;
    subscribe: (listener: () => void) => () => void;
    private operation;
    signIn(options?: SignInOptions): Promise<Readonly<Readonly<{
        status: "unconfigured" | "signed-out" | "signing-in" | "restoring" | "signed-in" | "reauthentication-required" | "unavailable";
        authority: Readonly<{
            id: string;
            identityOrigin: string;
            apiBasePath: string;
            /** `at-launch` builds sign in before the app opens; see LaunchSignIn. */
            signIn: "on-demand" | "at-launch";
            /** Display name for sign-in copy, such as "Block". */
            organization: string | null;
            /** The community hosts it covers; match them with `coversCommunity`. */
            communityHosts: readonly string[];
        }> | null;
        revision: string;
        email: string | null;
        failure: string | null;
        /** When the signed-in session ends (RFC 3339). */
        expiresAt: string | null;
        /** The session ends soon; signing in again now keeps the app open. */
        expiring: boolean;
        /** A retired session's record is still stored because removing it
         * failed (`unavailable`); signing out again retries the removal. */
        cleanup: boolean;
        /** Signing in again waits on the browser while this session stays
         * signed in; `cancelSignIn` ends only that wait. */
        renewing?: boolean;
    }>>>;
    signOut(options?: {
        revision?: string;
    }): Promise<Readonly<Readonly<{
        status: "unconfigured" | "signed-out" | "signing-in" | "restoring" | "signed-in" | "reauthentication-required" | "unavailable";
        authority: Readonly<{
            id: string;
            identityOrigin: string;
            apiBasePath: string;
            /** `at-launch` builds sign in before the app opens; see LaunchSignIn. */
            signIn: "on-demand" | "at-launch";
            /** Display name for sign-in copy, such as "Block". */
            organization: string | null;
            /** The community hosts it covers; match them with `coversCommunity`. */
            communityHosts: readonly string[];
        }> | null;
        revision: string;
        email: string | null;
        failure: string | null;
        /** When the signed-in session ends (RFC 3339). */
        expiresAt: string | null;
        /** The session ends soon; signing in again now keeps the app open. */
        expiring: boolean;
        /** A retired session's record is still stored because removing it
         * failed (`unavailable`); signing out again retries the removal. */
        cleanup: boolean;
        /** Signing in again waits on the browser while this session stays
         * signed in; `cancelSignIn` ends only that wait. */
        renewing?: boolean;
    }>>>;
    cancelSignIn(): Promise<void>;
    recheck(): Promise<Readonly<Readonly<{
        status: "unconfigured" | "signed-out" | "signing-in" | "restoring" | "signed-in" | "reauthentication-required" | "unavailable";
        authority: Readonly<{
            id: string;
            identityOrigin: string;
            apiBasePath: string;
            /** `at-launch` builds sign in before the app opens; see LaunchSignIn. */
            signIn: "on-demand" | "at-launch";
            /** Display name for sign-in copy, such as "Block". */
            organization: string | null;
            /** The community hosts it covers; match them with `coversCommunity`. */
            communityHosts: readonly string[];
        }> | null;
        revision: string;
        email: string | null;
        failure: string | null;
        /** When the signed-in session ends (RFC 3339). */
        expiresAt: string | null;
        /** The session ends soon; signing in again now keeps the app open. */
        expiring: boolean;
        /** A retired session's record is still stored because removing it
         * failed (`unavailable`); signing out again retries the removal. */
        cleanup: boolean;
        /** Signing in again waits on the browser while this session stays
         * signed in; `cancelSignIn` ends only that wait. */
        renewing?: boolean;
    }>>>;
    communityRequiresSignIn: typeof communityRequiresSignIn;
    askAgain: typeof askAgain;
    forCommunity: (relay: string) => FederatedIdentity;
    forServer: (id: string) => FederatedIdentity;
    request(request: AuthenticatedRequest): Promise<HostResponse>;
    private registration;
}
/** Every sign-in server this build trusts, the build's Builderlab first, as
 * native compiled them: none outside the desktop app. */
export declare function signInServers(): Promise<readonly SessionSnapshot[]>;
/** Forgets the issuer refusals native cached for a community this session,
 * so its next request asks the issuer again. Only for a person's retry. */
export declare function askAgain(relay: string): Promise<void>;
declare function communityRequiresSignIn(relay: string): Promise<boolean>;
/** `onSignedIn` for every sign-in server but the build's Builderlab. */
export declare function onCommunitySignedIn(reauthorize: () => void): () => void;
/** Calls `reauthorize` when the session, or any other sign-in server's,
 * becomes signed in or changes account, so every relay read it refused
 * retries at once instead of waiting for a manual Retry. Startup restore is
 * not a change: nothing was refused for it. */
export declare function onSignedIn(identity: FederatedIdentity, reauthorize: () => void): () => void;
export {};
