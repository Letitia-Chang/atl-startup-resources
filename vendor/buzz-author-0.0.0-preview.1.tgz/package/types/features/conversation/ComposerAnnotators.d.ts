import { type RefObject } from "react";
import type { ComposerInputElement } from "../messages/composer-dom";
import type { CompletionContext, ComposerAnnotator, ContributionReader } from "./contracts";
/** Mounts each registered annotator against the focused composer's draft and
 * shows their validated marks. `epoch` names the destination: changing it, or
 * `enabled`, revokes every publication and clears the marks. */
export declare function ComposerAnnotators({ registry, input, enabled, epoch, ...context }: CompletionContext & {
    registry: ContributionReader<ComposerAnnotator>;
    input: RefObject<ComposerInputElement | null>;
    enabled: boolean;
    epoch: string;
}): import("react").JSX.Element[] | null;
