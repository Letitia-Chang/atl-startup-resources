import type { RelaySession } from "../relay/session";
import type { ContributionReader, IdentityMark } from "./contracts";
/** Every active identity mark for `pubkey`, each in its own boundary so a
 * failing mark renders nothing and leaves the name and its row intact. */
export declare function IdentityMarks({ registry, pubkey, profiles, className, }: {
    registry: ContributionReader<IdentityMark> | undefined;
    pubkey: string;
    profiles: RelaySession["profiles"];
    className?: string | undefined;
}): import("react").JSX.Element | null;
