import { type ComposerSnapshot } from "../messages/mention-draft";
import type { ComposerInputElement } from "../messages/composer-dom";
import { type RefObject } from "react";
import type { ComposerCompletion, CompletionContext, CompletionQuery, ComposerObservation, ContributionReader, IdentityMark } from "./contracts";
import { type HostCompletionEdit } from "./completion";
import type { CompletionEditor } from "./useCompletionEditor";
export declare function ComposerCompletions({ registry, identityMarks, editor, input, replace, resolved, ...context }: CompletionContext & {
    registry: ContributionReader<ComposerCompletion>;
    identityMarks?: ContributionReader<IdentityMark> | undefined;
    editor: CompletionEditor;
    input: RefObject<ComposerInputElement | null>;
    /** Chip ranges and the draft text they were measured against. */
    resolved: Readonly<{
        text: string;
        document?: ComposerSnapshot;
        recipients: readonly Readonly<{
            start: number;
            end: number;
        }>[];
        /** Mentions still resolving; their `@` is no more an open query. */
        pending?: readonly Readonly<{
            start: number;
            end: number;
        }>[] | undefined;
        tokens?: readonly Readonly<{
            start: number;
            end: number;
        }>[] | undefined;
    }>;
    replace(edit: HostCompletionEdit, query: CompletionQuery, observation: ComposerObservation, key?: string): boolean;
}): import("react").JSX.Element | null;
