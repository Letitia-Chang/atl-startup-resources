import type { MentionDraft } from "./mention-draft";
/** Plain portions are authored Markdown, not rich-editor literal text. Keeping
 * their source verbatim avoids normalizing formats this slice does not edit.
 * Marked content uses CommonMark/GFM delimiter escaping and flanking rules.
 * A chip is its label as literal text in place. Copy passes `authored` to keep
 * the typed source without the namesake qualifiers a send adds. */
export declare function composerMarkdown(draft: MentionDraft, { authored }?: {
    authored?: boolean;
}): string;
