import type { ContributionReader, LinkPreviewRenderer } from "../conversation/contracts";
/** A message shows this many cards before the rest fold behind one button. */
export declare const FOLD_AFTER = 3;
export declare function LinkPreviews({ urls, messageId, registry, onOpenLink, }: {
    urls: readonly string[];
    messageId: string;
    registry: ContributionReader<LinkPreviewRenderer> | undefined;
    onOpenLink(url: string): boolean;
}): import("react").JSX.Element | null;
