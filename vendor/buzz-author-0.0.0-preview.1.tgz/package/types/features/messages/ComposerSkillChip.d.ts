import { type ComposerToken } from "./composer-token";
type SkillToken = Extract<ComposerToken, {
    kind: "skill";
}>;
/** A skill chip opens its details in place: a nested surface, never a visit. */
export declare function ComposerSkillChip({ token, returnCaret, }: {
    token: SkillToken;
    /** Puts the editor's caret right after this chip; false if it cannot. */
    returnCaret(): boolean;
}): import("react").JSX.Element;
export {};
