/** Selected keys participate in naming even if no longer eligible for another selection. */
export declare const SelectedMentionContext: import("react").Context<readonly Readonly<{
    pubkey: string;
    name: string;
}>[]>;
/** The agents a send from this composer addresses, as its session controls
 * show them; empty while editing. Host-internal. */
export declare const AddressedAgentsContext: import("react").Context<readonly string[]>;
