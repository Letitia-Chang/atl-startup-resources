import { type ReactNode, type ReactElement, type RefObject } from "react";
export declare const useAfterMessageMenuClose: () => ((action: () => void) => void) | undefined;
type Props = {
    /** A coordination row is the context-menu target instead of a toolbar. */
    children?: ReactElement | undefined;
    /** The target also shows the toolbar. A pointer open then leaves focus in
     * place, as ⋯ does, and Forward returns to ⋯. */
    withToolbar?: boolean | undefined;
    rowRef?: RefObject<HTMLDivElement | null>;
    messageId?: string;
    menuTriggerRef?: RefObject<HTMLButtonElement | null>;
    onSendToChannel?: (() => void) | undefined;
    onReply?: (() => void) | undefined;
    onForward?: (() => void) | undefined;
    replyDisabled?: boolean | undefined;
    link?: string | undefined;
    copyText(): string;
    quickControls?: ReactNode;
    toolbarItems?: ReactNode;
    /** Menu items rendered above the built-in actions. */
    leadingItems?: ReactNode;
    overflowItems?: ReactNode;
};
/** The context menu of the toolbar message rows rendered inside `children`. */
export declare function MessageContextMenus({ children }: {
    children: ReactElement;
}): import("react").JSX.Element;
export declare function MessageActionBar(props: Props): import("react").JSX.Element | null | undefined;
export {};
