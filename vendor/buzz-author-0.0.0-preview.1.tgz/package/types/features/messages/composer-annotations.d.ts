import { Plugin, type EditorState, type Transaction } from "prosemirror-state";
import { DecorationSet } from "prosemirror-view";
import type { Node as EditorNode } from "prosemirror-model";
import type { AnnotationObservation, ComposerReplacement, InlineRange } from "../conversation/contracts";
/** Per annotator, per publication. */
export declare const ANNOTATION_LIMIT = 200;
export declare const ANNOTATION_EDITOR_LIMIT = 400;
export declare const ANNOTATION_LABEL_LENGTH = 120;
export declare const REPLACEMENT_LIMIT = 5;
export declare const REPLACEMENT_LENGTH = 64;
/** A host-validated annotation, frozen, with the contribution that published it. */
export type AnnotationMark = Readonly<{
    key: string;
    start: number;
    end: number;
    text: string;
    label: string;
    kind: "spelling" | "grammar" | undefined;
    replacements: readonly Required<ComposerReplacement>[];
}>;
/** One number per immutable document, never reused across editors, so a result
 * for an earlier document (even with the same text) is never current. */
export declare function annotationRevision(doc: EditorNode): number;
/** Runs of plain text inside one block, in the editable-text projection. Code,
 * link labels, literals, mention text, chips, line breaks and raw Markdown
 * syntax are excluded; formatting marks do not split a run. */
export declare function proseSpans(doc: EditorNode): InlineRange[];
/** Copy at most `ANNOTATION_LIMIT` well-formed annotations from a publication,
 * dropping any that do not exactly match the observed prose, or nothing for a
 * publication that is not an array. Of overlapping annotations, the one that
 * starts first is kept. */
export declare function acceptedAnnotations(raw: unknown, observation: AnnotationObservation, key: string): AnnotationMark[] | undefined;
/** Combine annotators in contribution order: earlier ones win overlaps, and an
 * editor shows at most `ANNOTATION_EDITOR_LIMIT` marks. */
export declare function mergedAnnotations(groups: readonly (readonly AnnotationMark[])[]): Readonly<{
    key: string;
    start: number;
    end: number;
    text: string;
    label: string;
    kind: "spelling" | "grammar" | undefined;
    replacements: readonly Required<ComposerReplacement>[];
}>[];
/** Underlines for the marks shown at the current revision. After an edit the
 * marks stop being actionable; underlines whose text changed are dropped, others
 * follow their text until the next publication. Under an IME composition the
 * underlines only move, so the composing text node is left alone. */
export declare function annotationPlugin(className: string, composing: () => boolean): Plugin<Readonly<{
    revision: number;
    marks: readonly AnnotationMark[];
    set: DecorationSet;
}>>;
/** A transaction showing `marks`, or nothing when the revision is no longer current. */
export declare function showAnnotations(state: EditorState, revision: number, marks: readonly AnnotationMark[]): Transaction | undefined;
/** The marks actionable now: those last shown, until the draft changes. A
 * withdrawn or replaced publication's marks are no longer among them. */
export declare function shownAnnotations(state: EditorState): readonly AnnotationMark[];
/** The actionable mark at a document position, only at the revision it was shown for. */
export declare function annotationAt(state: EditorState, position: number): Readonly<{
    key: string;
    start: number;
    end: number;
    text: string;
    label: string;
    kind: "spelling" | "grammar" | undefined;
    replacements: readonly Required<ComposerReplacement>[];
}> | undefined;
/** Replace a shown mark's text with one of its replacements, as its own undo
 * step. The text must still be the same uniformly formatted run at the same
 * revision; the caret, when inside it, moves after the replacement. */
export declare function replaceAnnotation(state: EditorState, revision: number, target: Readonly<{
    start: number;
    end: number;
    text: string;
}>, replacement: string): Transaction | undefined;
