import type { ChannelSummary } from "../relay/contracts";
import type { ComposerSession } from "./composer-session";
import type { MentionRecipient } from "./mention-draft";
/** The shared forward-looking rule applied to mention recipients: archived
 * here or being deleted ({@link agentUnavailable}). */
export declare function archivedMention(session: ComposerSession, pubkey: string): boolean;
/**
 * Whether a destination can name people outside it from the community
 * directory. A Solo chat cannot: its mentions admit agents through the Solo chat
 * choice policy. This follows the channel type, not composer props, because
 * some Solo chat composers (media comments, edits) do not carry Solo mode.
 */
export declare function allowsOutsideMentions(channel: Pick<ChannelSummary, "channelType"> | undefined): boolean;
/**
 * Which keys a draft may address in this destination, read once from current
 * state. The host owns this rule; the mentions plugin offers a subset of it and
 * owns its order and labels. Delivery checks membership again and asks before
 * addressing outside people.
 */
export declare function mentionAdmission(session: ComposerSession, channelId: string, inviteAgents?: boolean, roster?: readonly MentionRecipient[], 
/** The owner's agents from their other communities: bringing one here
 * takes it out of its archive here, as after a Remove. */
bringable?: ReadonlySet<string>): (pubkey: string) => boolean;
/**
 * The recipient a pasted identity link adds, under its current name, or null.
 * The pasted label is never the name: it could disguise the invitee. A key
 * with no known name is accepted only if it is a member; otherwise the link
 * stays display-only, as the chooser would not offer it.
 */
export declare function pastedMentionRecipient(session: ComposerSession, channelId: string, pubkey: string, inviteAgents?: boolean, roster?: readonly MentionRecipient[]): MentionRecipient | null;
