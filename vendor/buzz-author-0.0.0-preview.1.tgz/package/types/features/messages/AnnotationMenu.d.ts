import { type RefObject } from "react";
import type { AnnotationMenuRequest, ComposerInputElement } from "./composer-dom";
/** One shown annotation's label and replacements. Picking one asks the editor
 * to replace the text, which it refuses if the draft moved on; any edit, the
 * annotation being withdrawn or replaced, or a composition starting closes the
 * menu first. Focus returns to the editor. */
export declare function AnnotationMenu({ request, input, onClose, }: {
    request: AnnotationMenuRequest;
    input: RefObject<ComposerInputElement | null>;
    onClose(): void;
}): import("react").JSX.Element;
