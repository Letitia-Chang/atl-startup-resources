import { type Node as EditorNode } from "prosemirror-model";
/** The identity locator a whole source is: `[@Name](nostr:npub…)`. */
export declare function identityLink(source: string): {
    pubkey: string;
    name: string;
} | undefined;
/** Both clipboard flavors of a composer document. `text` is the Markdown source
 * as a reader expects it; `html` carries every locator for this app's own paste
 * handler and other rich editors. */
export declare function composerClipboard(doc: EditorNode, document: Document): {
    text: string;
    html: string;
};
/** This app's own `text/html` payload as editor content; other HTML is never
 * read. Its blocks and marks paste as they are, while anchors and line breaks
 * become source text: the host's decorations decide which links are chips, as
 * for typed source, and paragraphs keep line breaks as text. */
export declare function buzzCopyDocument(html: string): EditorNode | undefined;
/** The files a paste attaches. Office and iWork put a picture of copied text
 * beside it, which WebKit offers as an image file; when the HTML flavor has
 * text, those images render it and the paste is that text. Every text path,
 * raw and code included, can fall back to plain text, so it must have some. */
export declare function pastedFiles(data: DataTransfer | null): File[];
/** External HTML contributes web links, never Buzz identity metadata or styling. */
export declare function externalLinkMarkdown(html: string, plain?: string): string | undefined;
