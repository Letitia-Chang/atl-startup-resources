import { scanMarkdown } from "../relay/message-content";
export type LiteralRange = Readonly<{
    start: number;
    end: number;
}>;
type MarkdownNode = {
    type: string;
    children?: MarkdownNode[] | undefined;
    position?: {
        start: {
            offset?: number | undefined;
        };
        end: {
            offset?: number | undefined;
        };
    } | undefined;
};
export type PreparedMarkdown = Readonly<{
    kind: "plain";
    content: string;
}> | Readonly<{
    kind: "markdown";
    content: string;
    literalRanges: readonly LiteralRange[];
    spoilerDelimiters: readonly number[];
}>;
export declare const isLiteralMarkdownContext: (type: string) => boolean;
export declare function literalRanges(tree: MarkdownNode, includeLinks: boolean): readonly LiteralRange[];
/** Prose that no Markdown, GFM or message syntax acts on: no syntax characters,
 * `:` (shortcodes, URL schemes), `@`, `www.`, private-use placeholders, tabs or
 * other controls, line-start list or indent markers, or a space before a line
 * ending. Its tree is paragraphs of text, which `plainProseTree` builds. */
export declare const isPlainProse: (content: string) => boolean;
/** The tree micromark builds for `isPlainProse` content. */
export declare const plainProseTree: (content: string) => {
    type: string;
    children: {
        type: string;
        children: {
            type: string;
            value: string;
        }[];
    }[];
};
/** Pure, immutable Markdown work; `preparedMarkdown` keeps recent results.
 * `scanned` receives the prepared content's scan when one was made. */
export declare function prepareMarkdown(content: string, scanned?: (scan: ReturnType<typeof scanMarkdown>) => void): PreparedMarkdown;
/** Switching channels remounts every row. Keep recent results so a revisit
 * does not prepare and parse unchanged bodies again. */
export declare function recentResults<T>(budget: number, weigh: (key: string, value: T) => number): (key: string, make: () => T) => T;
/** A message body's prepared Markdown, shared by its renderer and link
 * previews so a row prepares it once. */
export declare const preparedMarkdown: (content: string, scanned?: Parameters<typeof prepareMarkdown>[1]) => PreparedMarkdown;
export {};
