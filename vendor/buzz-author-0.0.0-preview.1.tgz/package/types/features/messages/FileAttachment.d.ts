import type { FileCardProps } from "../conversation/contracts";
export declare function formatFileSize(size: number): string;
export declare function FileAttachment({ attachment, source, onOpenLink, onPreview, typeLabel, }: Omit<FileCardProps, "source"> & {
    source: string | undefined;
}): import("react").JSX.Element;
