import type { MessageReaction } from "../relay/contracts";
import { type CustomEmoji } from "../relay/emoji";
import type { RelaySession } from "../relay/session";
/** Resolve a `:shortcode:` against one index per custom-emoji catalog snapshot. */
export declare function catalogEmoji(entries: readonly CustomEmoji[], content: string): Readonly<{
    shortcode: string;
    url: string;
}> | undefined;
/** The emoji a reaction slot draws: its own NIP-30 tag, else, for a tagless
 * `:shortcode:` (agents send these), the community palette's entry. */
export declare function useReactionEmoji(reaction: MessageReaction, session: RelaySession): Readonly<{
    shortcode: string;
    url: string;
}> | undefined;
