/** The HTTPS links a message's prose names, in order, once each: bare,
 * labeled and reference links, but not `<url>`, which asks for no preview,
 * nor links in code or spoilers, nor ones naming one of `exclude`. */
export declare function previewLinks(content: string, exclude?: readonly string[]): readonly string[];
