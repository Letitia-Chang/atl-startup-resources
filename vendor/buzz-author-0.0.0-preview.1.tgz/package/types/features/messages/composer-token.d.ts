import type { JsonValue } from "../navigation/targets";
/** A host-internal semantic editor atom, separate from notification
 * recipients. Only bundled completion providers create one; it is not part of
 * the plugin contract. Extra JSON fields round-trip without interpretation. */
export type ComposerToken = Readonly<({
    kind: "folder";
    id: string;
    label: string;
} | {
    kind: "skill";
    id: string;
    label: string;
    target: string;
}) & {
    readonly [key: string]: JsonValue | undefined;
}>;
/** Copy only bounded JSON. A provider cannot retain mutable editor metadata or
 * turn a token into a recipient through a label, prototype or callback. */
export declare function composerToken(value: unknown): ComposerToken | undefined;
/** The text a chip stands for in the draft and the sent message; the chip
 * itself shows its label. An agent invokes a skill as `$name` and opens a
 * folder by its path. */
export declare function composerTokenText(token: ComposerToken): string;
export declare function composerTokenName(token: ComposerToken): string;
