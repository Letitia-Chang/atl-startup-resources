import { type ComposerToken } from "./composer-token";
import type { MentionDraft } from "./mention-draft";
/** A message's chips, signed by the author's own composer. Readers trust them
 * only as far as they trust that author. */
export declare const MESSAGE_TOKENS_TAG = "buzz-tokens-v1";
export declare function messageTokenTags(tokens: readonly ComposerToken[]): string[][];
/** Host composers only: the first message `send` or `reply` that `publish`
 * makes synchronously carries these chips. A send made while it is queued,
 * such as by an outbox subscriber, does not. The public message API cannot
 * add them. */
export declare function signMessageTokens<T>(tokens: readonly ComposerToken[], publish: () => T): T;
/** The tag for the chips `signMessageTokens` is publishing, if any. The first
 * caller takes them. */
export declare function signedMessageTokenTags(): string[][];
/** Unknown versions are inert. Never recover chips from prose. */
export declare function readMessageTokens(tags: readonly (readonly string[])[]): readonly ComposerToken[];
/** The chips a draft's message signs. */
export declare function draftTokens(draft: Pick<MentionDraft, "document">): ComposerToken[];
