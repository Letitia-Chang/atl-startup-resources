import type { AgentKey } from "./membership";
import type { AgentStore } from "./store";
import type { TurnInstructions } from "./service";
/** The conversation's instructions and the plugin that gave them. Empty text
 * means they were cleared, so a turn says none apply now; undefined means it
 * never had any. */
export declare function conversationInstructions(store: AgentStore, scope: string, agent: AgentKey, conversation: string): TurnInstructions | undefined;
/** Replaces the conversation's instructions with `text`, which `plugin`
 * gave; empty text clears them. Clearing a conversation that never had any
 * keeps nothing, so its turns say nothing of them. */
export declare function setConversationInstructions(store: AgentStore, scope: string, agent: AgentKey, conversation: string, plugin: string, text: string): Promise<void>;
/** Drops every conversation's instructions for the agent, in every scope.
 * A failure only warns: it must not stop the agent's removal. */
export declare function forgetConversationInstructions(store: AgentStore, agent: AgentKey): Promise<void>;
