/** Convert before native takes custody; its upload still owns persistence. */
export declare function importedEmojiPicture(picture: string | undefined): Promise<{
    source: string;
    png: string;
} | undefined>;
