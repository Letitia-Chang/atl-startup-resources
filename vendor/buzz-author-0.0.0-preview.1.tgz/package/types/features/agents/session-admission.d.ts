import type { Context } from "@deepseek-ai/cordis";
import type { JsonValue } from "../navigation/targets";
import type { RelayEvent } from "../relay/events";
import type { AgentKey } from "./membership";
import type { AgentStore } from "./store";
export type AgentSessionSource = Readonly<{
    channelId: string;
    root?: string;
}>;
export type AgentSessionAdmission = Readonly<{
    agent: AgentKey;
    owner: string;
    harness: string;
    source: AgentSessionSource;
    /** The native conversation scope. It can include several source threads. */
    conversation: AgentSessionSource;
    invocationId: string;
    event?: RelayEvent;
    sessionKey: string;
    intent: "new" | "existing";
    resumed: boolean;
    /** The host adopts a source lifetime with no saved logical association. */
    adopted: boolean;
    association?: JsonValue;
    signal: AbortSignal;
}>;
export type AgentSessionAssociation = Readonly<{
    sessionKey: string;
    router: string;
    association: JsonValue;
}>;
type AdmissionRequest = Omit<AgentSessionAdmission, "sessionKey" | "intent" | "association" | "adopted">;
export type AgentSessionRouter = Readonly<{
    id: string;
    /** Opens local keyed storage. This must not wait for a sidebar or relay. */
    ready(): Promise<void>;
    matches(input: Pick<AgentSessionAdmission, "agent" | "owner" | "harness" | "source">): boolean;
    /** Saves the local association before returning. Undefined leaves the run unchanged. */
    prepare(input: AgentSessionAdmission): Promise<Readonly<{
        association: JsonValue;
        context?: string;
    }> | undefined>;
}>;
export declare const SESSION_ADMISSION_PREFIX = "buzz.agents.session-admission.v1:";
/** Logical lifetimes survive harness reconnects. Each invocation keeps its own key. */
export declare function createSessionAdmissions(root: Context, storage: AgentStore): {
    register(ctx: Context, router: AgentSessionRouter): void;
    prepare(input: AdmissionRequest): Promise<Readonly<{
        acknowledged: () => void;
        session: Readonly<{
            sessionKey: string;
            router: string;
            association: JsonValue;
        }>;
        context?: string;
    }> | undefined>;
    reset(agent: AgentKey, harness: string, source: AgentSessionSource, run: () => Promise<void>): Promise<void>;
};
export {};
