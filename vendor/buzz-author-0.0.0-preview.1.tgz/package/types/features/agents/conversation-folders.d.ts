import type { AgentKey } from "./membership";
import type { AgentStore } from "./store";
/** A conversation as harnesses key their sessions: a channel, or one of its
 * threads. */
export declare const conversationKey: (channelId: string, root?: string) => string;
/** The folder the conversation was given, as it was resolved then; it may no
 * longer exist. */
export declare function conversationFolder(store: AgentStore, scope: string, agent: AgentKey, conversation: string): string | undefined;
/** Every folder the agent's conversations were given, by conversation. */
export declare function agentFolders(store: AgentStore, scope: string, agent: AgentKey): Map<string, string>;
/** Gives the conversation `folder`, an existing directory's resolved path.
 * Giving it the folder it has again is a no-op; any other folder rejects. */
export declare function assignConversationFolder(store: AgentStore, scope: string, agent: AgentKey, conversation: string, folder: string): Promise<string>;
/** `folder`, checked to still be a directory without creating it, for a turn
 * to start in. A removed one rejects naming it: the turn never falls back to
 * the agent's workspace. */
export declare function existingFolder(resolve: ((path: string, options: {
    create: false;
}) => Promise<string>) | undefined, folder: string): Promise<string>;
