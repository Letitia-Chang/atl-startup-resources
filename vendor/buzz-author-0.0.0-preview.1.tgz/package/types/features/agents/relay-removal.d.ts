import type { LocalEvents } from "../relay/outbox";
import type { IdentityAttest } from "../relay/identity-archives";
import type { RelaySession } from "../relay/session";
type RemovalSession = Pick<RelaySession, "outbox" | "channels" | "channelWrites" | "archives">;
/** A fresh owner proof (NIP-OA) for an agent the caller owns. */
export type OwnerProof = (pubkey: string, signal: AbortSignal) => Promise<readonly string[]>;
/** How the caller proves it owns an agent: `issue`, a fresh owner proof
 * (NIP-OA); `attest`, only with the agent's key, republishes its own profile
 * with its saved owner proof when the profile has none. */
export type OwnerConsent = {
    issue: OwnerProof;
    attest?: IdentityAttest;
};
/** Archives the agent unless a read started now finds it archived already, so
 * a retry goes on past it. Rejects unless the relay confirms the archive.
 * "skipped": the community advertises no archive authority, so nothing is
 * hidden by one there and Delete goes on without it. */
export declare function archiveAgent(session: Pick<RelaySession, "archives">, pubkey: string, signal: AbortSignal, owner?: OwnerConsent): Promise<"archived" | "skipped">;
/** Remove a relay-only agent from this community: archive its identity,
 * delete the owner's kind 30177 record, then try to remove it from its
 * channels. Archive and record deletion must succeed; a refusal stops the
 * later steps and Remove stays retryable. Channel removal is best effort: its
 * failure does not fail the removal. */
export declare function removeRelayAgent(session: RemovalSession, viewer: string, pubkey: string, signal: AbortSignal, owner?: OwnerConsent): Promise<void>;
/** The content and tags of a kind 30177 record as read. */
export type AgentRecordBody = Readonly<{
    content: Readonly<Record<string, unknown>>;
    tags: readonly (readonly string[])[];
}>;
/** The viewer's own kind 30177 record of an agent, as Agents writes it. */
export type AgentRecordEntry = Readonly<{
    pubkey: string;
    name: string;
    /** An HTTPS image URL. */
    picture?: string;
    /** The agent type's key, `pluginId/typeId`, as the `runtime` tag. */
    runtime: string;
    /** The record this replaces, whose other settings and tags it keeps. */
    prior?: AgentRecordBody | undefined;
}>;
/** Publishes the viewer's kind 30177 record of an agent, replacing any
 * before it, and resolves with what it wrote once the relay accepts it.
 * Another desktop applies the record whole to an agent it has with that key,
 * and its parser requires `parallelism` and `respond_to`, so the record keeps
 * every setting of the one it replaces and defaults those two
 * (docs/relay-queries.md, "Managed-agent registration"). */
export declare function publishAgentRecord(session: Pick<RelaySession, "outbox">, { pubkey, name, picture, runtime, prior }: AgentRecordEntry, signal: AbortSignal): Promise<AgentRecordBody>;
/** NIP-09 coordinate deletion of the viewer's own kind 30177 agent record. */
export declare function deleteAgentRecord(session: Pick<RelaySession, "outbox">, viewer: string, pubkey: string, signal: AbortSignal, fence?: AbortSignal): Promise<void>;
/** Base Buzz `removeAgentFromAllChannels` over the relay's rosters for this
 * agent plus the viewer's loaded channels, skipping archived ones. Resolves
 * only once a fresh relay read lists the agent in none of them; any refusal or
 * unknown outcome throws after every channel operation has settled. */
export declare function removeAgentFromChannels(session: Pick<RelaySession, "outbox" | "channels" | "channelWrites">, pubkey: string, signal: AbortSignal): Promise<void>;
/** Settles once the outbox reports the relay accepted `id`, or rejects with
 * its refusal. */
export declare function delivered(outbox: LocalEvents, id: string, signal: AbortSignal, failure: string): Promise<void>;
export {};
