export declare const DEFAULT_REPOSITORIES_FOLDER = "~/.buzz/REPOS";
export declare function repositoriesKey(community: string, viewer: string): string;
/** Paths are data, never shell fragments or prompt markup. Native save also checks the directory. */
export declare function repositoriesPath(value: string): string;
export declare function readRepositoriesFolder(community: string, viewer: string): string;
/** Required readback; never reports a failed or ignored write as saved. */
export declare function saveRepositoriesFolder(community: string, viewer: string, value: string): string;
export type RepositoryFolder = Readonly<{
    name: string;
    path: string;
    displayPath: string;
}>;
/** The folder `repositoryFolders` lists for `partition` now. */
export declare function repositoriesFolder(partition: string): string;
/** The immediate folders of `partition`'s configured repositories folder, or
 * of the default one. Native code checks only the folder `list` is given; the
 * caller's community and account choose it. Rejects if `signal` aborts or the
 * preference changes meanwhile. Never creates the folder. */
export declare function repositoryFolders(partition: string, signal: AbortSignal, list: (path: string) => Promise<readonly RepositoryFolder[]>): Promise<readonly Readonly<{
    name: string;
    path: string;
    displayPath: string;
}>[]>;
/** Captured agent community/account, never the selected community. No filesystem changes. */
export declare function repositoriesContext(partition: string | undefined): string;
