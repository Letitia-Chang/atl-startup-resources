import { type ComponentProps, type ReactNode } from "react";
import type { ExtraProps } from "react-markdown";
import type { CodeBlockRenderer, ContributionReader } from "../conversation/contracts";
/** The frame and action classes a host gives its code blocks; messages pass
 * their own, which compose these. */
export type CodeClasses = Readonly<{
    frame: string | undefined;
    actions: string | undefined;
}>;
/** WebKit adds an `overflow-x: auto` scrollbar after flex and grid ancestors
 * have taken their heights, then lays out only the table again. A scrollbar
 * that takes space then overlaps the next row, or leaves a gap when removed.
 * CSS chooses the scrollbar from measured overflow so it is laid out with
 * the ancestors. Observe content too: edits can change scrollWidth without
 * resizing a table at its width cap. Measure on mount because the resize
 * observer's first report arrives after the row's. */
export declare function observeTableOverflow(table: HTMLTableElement | null): (() => void) | undefined;
/** The fence's info-string language, as remark records it on the inner `code`. */
export declare function codeLanguage(pre: ExtraProps["node"]): string | undefined;
/** A fenced block's `pre`: the plain code with an optional copy action, or,
 * when a registry is given and the fence names a language, a plugin's
 * presentation with the plain code as its fallback. */
export declare function CodeFence({ node, children, copy, registry, classes, ...props }: ComponentProps<"pre"> & ExtraProps & {
    copy: boolean | undefined;
    registry: ContributionReader<CodeBlockRenderer> | undefined;
    classes?: CodeClasses | undefined;
}): import("react").JSX.Element;
/** A plugin presents the block and may add an action; the host keeps the frame,
 * action placement and copy, and restores the plain code when the plugin fails
 * or is removed. */
export declare function CodeBlock({ registry, language, code, fallback, classes, }: {
    registry: ContributionReader<CodeBlockRenderer>;
    language: string;
    code: string;
    fallback: ReactNode;
    classes?: CodeClasses | undefined;
}): string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | Iterable<ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | null | undefined;
export declare function CodeActions({ code, children, className, }: {
    code: string;
    children?: ReactNode;
    className?: string | undefined;
}): import("react").JSX.Element;
