import { type IdentityArchiveAction } from "./identity-archive-protocol";
import type { RelayReader } from "./reader";
import type { RelayWriter } from "./transport";
export type IdentityArchiveSnapshot = Readonly<{
    status: "unavailable" | "idle" | "loading" | "ready" | "error";
    archived: readonly string[];
    eventId?: string;
    createdAt?: number;
    readAt?: number;
    error?: string;
}>;
export type IdentityArchives = ReturnType<typeof createIdentityArchives>["queries"];
/** Base Buzz discovery rule: known-archived identities leave forward-looking
 * choices, fail open while archive state is unknown, and never hide the viewer
 * from themself (NIP-IA archival stays visible to its subject). Visibility
 * uses the last known archives; `state()` answers only from a fresh read. */
/** The relay archives an owned identity only when its latest profile names
 * its owner, and the caller can't publish that profile. */
export declare class UnattestedProfile extends Error {
    constructor();
}
/** Publishes an identity's profile as that identity. */
/** Republishes an identity's own profile, naming its saved owner. */
export type IdentityAttest = (signal: AbortSignal) => Promise<unknown>;
export declare function archiveHides(archives: Pick<IdentityArchives, "snapshot"> | undefined, pubkey: string, viewer: string | undefined): boolean;
/** Relay-scoped NIP-IA visibility, never access, membership or liveness evidence.
 * The caller supplies only explicit NIP-11 self, never the contact-key fallback.
 * Reads are lazy finite snapshots, not a live archive subscription.
 * Requests are optional NIP-IA 9035/9036 writes; the relay re-verifies consent. */
export declare function createIdentityArchives(reader: RelayReader, authority: string | undefined, notify?: (listener: () => void) => void, write?: {
    writer: RelayWriter | undefined;
    viewer: string | undefined;
}): {
    queries: Readonly<{
        snapshot: () => Readonly<{
            status: "unavailable" | "idle" | "loading" | "ready" | "error";
            archived: readonly string[];
            eventId?: string;
            createdAt?: number;
            readAt?: number;
            error?: string;
        }>;
        subscribe(listener: () => void): () => void;
        state: (pubkey: string) => "unknown" | "archived" | "not-archived";
        ensure: () => Promise<void>;
        refresh: () => Promise<void>;
        /** Whether this community advertises an archive authority; fixed per session. */
        supported: boolean;
        writable: boolean;
        consent: (target: string, signal: AbortSignal) => Promise<{
            auth?: readonly string[];
            admin?: true;
        } | null>;
        request: (action: IdentityArchiveAction, target: string, caller?: AbortSignal, issue?: (target: string, signal: AbortSignal) => Promise<readonly string[]>, attest?: IdentityAttest) => Promise<void>;
    }>;
    clear: () => void;
    stale: () => void;
    dispose(): void;
};
