import type { RelayReader } from "./reader";
import type { RelayWriter } from "./transport";
import { type RelayEvent } from "./events";
import { type ChannelLifecycleCommand, type ChannelLifecycleSettings } from "./channel-lifecycle-protocol";
/** No automatic or same-dialog retry after a request may have reached the relay. */
export declare class ChannelLifecycleUnconfirmed extends Error {
    constructor(reason: unknown);
}
export type DmVisibility = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    hidden: readonly string[];
    error?: string;
}>;
export interface ChannelLifecycleCapability {
    readonly available: boolean;
    load(channelId: string, signal?: AbortSignal, 
    /** The channel's relay records the caller already read, so its answer and
     * these rights share one snapshot; omitted, load reads them. */
    records?: readonly RelayEvent[]): Promise<ChannelLifecycleSettings>;
    run(action: ChannelLifecycleCommand, channelId: string, signal?: AbortSignal, 
    /** Checked synchronously right before publishing; false publishes nothing. */
    active?: () => boolean): Promise<void>;
    snapshot(): DmVisibility;
    subscribe(listener: () => void): () => void;
    /** `ifStale` lets a read that succeeded within `FRESH_FOR` answer, for
     * triggers that only suggest visibility may have changed. `trailing` needs
     * a read that starts after this call: repeated calls during a pending read
     * share one more read after it. */
    refreshVisibility(signal?: AbortSignal, options?: {
        ifStale?: boolean;
        trailing?: boolean;
    }): Promise<void>;
    observeRemoval(listener: (channelId: string) => void): () => void;
}
export declare function createChannelLifecycle({ reader, writer, viewer, relayAuthor, canAccess, acceptDiscovery, removed, }: {
    reader?: RelayReader | undefined;
    writer?: RelayWriter | undefined;
    viewer: string;
    relayAuthor: string;
    canAccess(id: string): boolean;
    acceptDiscovery(events: readonly RelayEvent[]): void;
    removed(id: string): void;
}): {
    capability: ChannelLifecycleCapability;
    /** Abort unpublished work on `ids` and id-less visibility reads; without
     * `ids`, all unpublished work. */
    cancel(ids?: readonly string[]): void;
    clear(): void;
    dispose(): void;
};
