/** Display-only avatars. No file URLs, arbitrary SVG, executable schemes or
 * credentials; old Buzz's emoji SVG renders only as rebuilt from its parts. */
export declare function avatarSource(value: unknown): string | undefined;
/** Old Buzz's emoji avatar, still written by Buzz mobile, as its emoji and
 * background. Matches only that exact template, never arbitrary SVG. */
export declare function legacyEmojiPicture(picture: string): {
    emoji: string;
    color: string;
} | undefined;
/** Displayable small avatar: inline data as-is, remote art through the
 * session's authenticated media path (never the raw URL). */
export declare function avatarMedia(value: unknown, media: ((url: string, size: "small") => string | undefined) | undefined): string | undefined;
