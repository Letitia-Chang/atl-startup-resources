type Revision = string | null | undefined;
type Operation = "write" | "notify" | "storage" | "persist" | "saved" | "changed" | "failed" | "load" | "reconcile" | "keep" | "use-saved" | "send-start" | "send-start-conflict" | "send-upload-conflict" | "send-prepare-conflict" | "send-publish-conflict" | "write-mismatch" | "serialize-failed" | "write-failed" | "notify-failed";
type Comparison = {
    expected: Revision;
    current: Revision;
    next: Revision;
    flags: number;
};
export declare const draftEditorId: () => number;
/** Only comparisons and local numeric IDs enter the trace. No revision is retained. */
export declare function traceDraft(scope: string, key: string, operation: Operation, editor?: number, comparison?: Comparison): void;
export {};
