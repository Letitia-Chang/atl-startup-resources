import type { AgentHandle } from "../features/agents/service";
import type { BuzzClient, Context } from "./client";
import { type AgentToolOperation, type AgentToolProof } from "../features/agents/tool-operation";
import { type Reply, type Tool } from "./tools";
/** A tool a plugin adds to every agent session in the app, listed after
 * the Buzz tools under the same server and loaded on search. Its name should
 * start with its plugin's, as `notes_get` does; no two tools share one. */
export type AddedTool = Readonly<{
    name: string;
    description: string;
    inputSchema: Readonly<Record<string, unknown>>;
    /** A provider operation checked with these exact tool arguments. */
    operation?: AgentToolOperation;
    /** Runs as the agent in `context`. Use `client.signal` to cancel waits and
     * check it before external writes. A throw is a tool error for the agent. */
    call(client: BuzzClient, context: Context, args: Record<string, unknown>, proof?: AgentToolProof): Promise<Reply>;
}>;
type Listed = Pick<AddedTool, "name" | "description" | "inputSchema">;
export { isFinalMessage, isMessageTool, MESSAGE_TOOLS, } from "./message-tools";
export type BuzzSession = Readonly<{
    tools: readonly Tool[];
}>;
/** What every session of an agent in the app gets. It never changes with
 * the owner's attention setting, so a session (and its cached prompt prefix)
 * never needs replacing when attention is turned on or off: the attention
 * tools refuse calls while it is off, and `turnNote` says which it is. */
export declare const BUZZ_SESSION: BuzzSession;
/** A tool as a session lists it. `search` means a harness that can load
 * tools on demand lists it by name only, and the model loads it when it
 * needs it; `always` means it is listed in full up front. Only the Buzz tools
 * choose: those plugins add always load on search, so installing plugins
 * never grows what every turn carries. */
export type SessionTool = Listed & Readonly<{
    load: "always" | "search";
}>;
/** The tools a session lists: the Buzz tools, then those plugins add. */
export declare const sessionTools: (added?: readonly AddedTool[]) => readonly SessionTool[];
/** What the server (Claude) or namespace (Codex) with the tools says up
 * front, so the model knows what it can search for. */
export declare function sessionHint(added?: readonly AddedTool[]): string;
/** Changes when the added tools change, so a session that keeps the list it
 * started with can be replaced; empty while plugins add none. A short hash,
 * since Codex saves it with each binding. Sorted by name, so the order
 * plugins start in does not change it. */
export declare function addedKey(added: readonly AddedTool[]): string;
/** Text for the end of a turn's prompt: the instructions plugins give the
 * agent now, then those for its conversation, which a harness names as it
 * names its notes', then its attention as it is now. An agent with no
 * Interests has nothing to review, so it need not load the attention tools to
 * find that out. */
export declare function turnNote(client?: Pick<BuzzClient, "attention"> & Pick<AgentHandle, "instructions" | "conversationInstructions">, channelId?: string, root?: string): string | undefined;
/** Answers one tool call. Throws when the tool cannot run now; the message
 * is for the agent. Without a client, no tool can be called yet. `added`
 * are the tools plugins add now. */
export declare function callSessionTool(client: BuzzClient | undefined, context: Context, name: string, args: Record<string, unknown>, added?: readonly AddedTool[]): Promise<Reply>;
