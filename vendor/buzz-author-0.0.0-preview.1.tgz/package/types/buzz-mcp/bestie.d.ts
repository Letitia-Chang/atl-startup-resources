import type { BuzzClient } from "./client";
import type { Tool } from "./tools";
export declare const BESTIE_TOOLS: readonly Tool[];
export declare const isBestieTool: (name: string) => boolean;
/** Runs Bestie tool `name` as `client`. A throw is a tool error. */
export declare function callBestieTool(client: BuzzClient, name: string, args: Readonly<Record<string, unknown>>): Promise<string>;
